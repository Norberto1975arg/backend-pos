const db = require('../config/conexion');

exports.obtenerClientes = (req, res) => {
  db.query('SELECT * FROM cliente', (err, results) => {
    if (err) {
      console.error('Error al obtener clientes:', err);
      res.status(500).json({ error: 'Error al obtener clientes' });
    } else {
      res.json(results);
    }
  });
};
